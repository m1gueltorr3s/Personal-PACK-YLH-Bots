// ==UserScript==
// @name         MOTHERFUCKER BOT YLH
// @namespace    https://github.com/m1gueltorr3s/Personal-PACK-YLH-Bots/
// @version      1.5
// @description  Monitorea y maneja ventanas en YouLikeHits y cierra ventanas emergentes de StayFocusd
// @author       m1gueltorr3s
// @updateURL    https://github.com/m1gueltorr3s/Personal-PACK-YLH-Bots/raw/refs/heads/PRINCIPAL/MOTHERFUCKER-YLH.user.js
// @downloadURL  https://github.com/m1gueltorr3s/Personal-PACK-YLH-Bots/raw/refs/heads/PRINCIPAL/MOTHERFUCKER-YLH.user.js
// @match        https://www.youlikehits.com/viewwebsite.php*
// @match        https://www.youlikehits.com/youtubenew2.php
// @match        https://www.youlikehits.com/websites.php
// @match        https://www.stayfocusd.com/blocked*
// @match        https://www.youlikehits.com/soundcloudplays.php
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // ================================
    // Función para actualizar la página YouLikeHits al detectar texto
    // ================================
    const targetTexts = [
        "There are no videos available to view at this time. Try coming back or refreshing.",
        "YouTube Limit\nYou have hit your Views Limit per 15 minutes.",
        "There are no Websites currently visitable for Points.",
        "You didn't view the video for the specified length of time.",
        "We couldn't find the video you're attempting to view.",
        "There are no more songs to play for points",
        "You have hit your Views Limit per 15 minutes."
    ];

    const checkYouLikeHitsTextUpdate = () => {
        if (targetTexts.some(text => document.body.textContent.includes(text))) {
            location.reload();
        }
    };

    setInterval(checkYouLikeHitsTextUpdate, 1600);

    // ================================
    // Función para cerrar ventanas emergentes de StayFocusd
    // ================================
    const closeStayFocusdWindows = () => {
        if (window.location.href.includes("https://www.stayfocusd.com/blocked")) {
            window.close();
        }
    };

    const stayFocusdObserver = new MutationObserver(closeStayFocusdWindows);
    stayFocusdObserver.observe(document.body, { childList: true, subtree: true });

    // Ejecuta la función para cerrar ventanas emergentes al cargar
    closeStayFocusdWindows();
})();
