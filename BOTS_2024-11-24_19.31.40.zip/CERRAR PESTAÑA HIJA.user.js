// ==UserScript==
// @name         Auto Close Child Tabs on YouLikeHits
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Cierra automáticamente las pestañas hijas que detecten "You got X Points!" en YouLikeHits
// @match        https://www.youlikehits.com/viewwebsite.php*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Función para cerrar la pestaña si se detecta el texto y es una pestaña hija
    function closeTabIfPointsDetected() {
        const regex = /You got \d+ Points!/i;
        if (regex.test(document.body.innerText) && window.opener) {
            window.close();
        }
    }

    // Ejecutar la función al cargar la página
    window.addEventListener('load', closeTabIfPointsDetected);

    // También verificar periódicamente por si el contenido se carga dinámicamente
    setInterval(closeTabIfPointsDetected, 1000);
})();
